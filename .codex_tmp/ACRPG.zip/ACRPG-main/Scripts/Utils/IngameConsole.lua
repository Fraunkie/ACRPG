--==================================================
-- IngameConsole.lua
-- See original .wct for full comments and implementation details
--==================================================

-- ...existing code from the extracted IngameConsole block...
